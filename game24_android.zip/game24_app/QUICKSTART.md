# 🚀 快速上手指南

## 一键获取APK的方法（最简单）

由于编译APK需要 Android SDK/NDK（约3GB），沙盒环境无法直接编译。
请按以下步骤操作，全程约15~30分钟：

### Step 1: 创建GitHub仓库
1. 打开 https://github.com/new
2. 仓库名填 `game24-android`
3. 选择 **Public**
4. 点击 **Create repository**

### Step 2: 上传代码
1. 下载本目录的 zip 包并解压
2. 将 `game24_app/` 目录下的所有文件上传到你的仓库
   - 需要上传的文件：`main.py`、`buildozer.spec`、`.github/` 文件夹、`README.md`
3. 或者直接把 `game24_android.zip` 上传后解压

### Step 3: 触发编译
1. 进入仓库 → 点击 **Actions** 标签页
2. 点击左侧 **Build APK**
3. 点击 **Run workflow** → 再点 **Run workflow**
4. 等待编译完成（绿色✅）

### Step 4: 下载APK
1. 点击刚才的 workflow run
2. 拉到底部 **Artifacts** 区域
3. 下载 `game24-apk` → 解压得到 `game24-1.0.0-debug.apk`
4. 传到手机安装即可 🎉

## 本地编译（有Linux环境时）

```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y openjdk-17-jdk zlib1g-dev libncurses5-dev \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  libgl1-mesa-dev libgles2-mesa-dev libffi-dev libssl-dev \
  autoconf automake libtool pkg-config unzip wget git cmake \
  build-essential

pip install buildozer cython==0.29.36

cd game24_app
buildozer android debug
# APK 在 bin/ 目录下
```

## 安装到手机

1. 将 APK 传到手机（微信/QQ/数据线均可）
2. 手机允许「未知来源安装」
3. 点击 APK 文件安装
4. 打开「算24点」开始游戏！

## 常见问题

**Q: 安装时提示"安装包解析失败"？**
A: 确认手机系统是 Android 5.0 (API 21) 以上

**Q: 编译失败？**
A: 检查 GitHub Actions 日志，通常是网络问题。重新运行即可

**Q: 想修改应用名称/图标？**
A: 编辑 `buildozer.spec` 文件，修改 `title` 和 `icon.filename`
