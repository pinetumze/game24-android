# 🎮 算24点 - 安卓App

10以内算24点游戏，Kivy + Buildozer 打包。

## 📱 快速使用

### 方式一：GitHub Actions 自动打包（推荐）

1. Fork 或上传本项目到你的 GitHub 仓库
2. 进入仓库 → **Actions** → 找到 **Build APK** → 点击 **Run workflow**
3. 等待约 15~30 分钟编译完成
4. 在 **Artifacts** 区域下载 `game24-apk.zip`，解压得到 `.apk` 文件
5. 手机安装即可（需允许「未知来源」安装）

### 方式二：本地编译

```bash
# 需要 Linux 环境（Ubuntu 推荐）
sudo apt install openjdk-17-jdk
pip install buildozer cython==0.29.36

cd game24_app
buildozer android debug
# APK 输出到 bin/ 目录
```

## 🎯 玩法

- 随机4张牌（1~10），用 + - × ÷ 和括号算出24
- 「我算出来了」→ 得分+1
- 「看答案」→ 显示所有解法（最多20种）
- 「跳过」→ 换下一题

## 📁 项目结构

```
game24_app/
├── main.py              # Kivy 主程序（界面 + 求解器）
├── buildozer.spec       # 安卓打包配置
├── .github/
│   └── workflows/
│       └── build_apk.yml  # GitHub Actions 自动编译
└── README.md
```

## 🛠 技术栈

- **Python 3.10** — 求解逻辑
- **Kivy 2.3** — 跨平台 UI
- **Buildozer** — 打包 APK

## ⚙️ 自定义

修改 `buildozer.spec` 中的：
- `title` — 应用显示名称
- `package.name` / `package.domain` — 包名
- `icon.filename` — 应用图标（放到同目录）
- `presplash.filename` — 启动闪屏图

## 📄 License

MIT
