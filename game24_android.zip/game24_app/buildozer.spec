[app]

# 应用名称
title = 算24点
package.name = game24
package.domain = com.yourname.game24

# 入口文件
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf
main.py = main.py

# 版本
version = 1.0.0

# 权限（最小化）
android.permissions = INTERNET
android.api = 31
android.minapi = 21
android.ndk = 25b
android.sdk = 31
android.accept_sdk_license = True

# 屏幕方向
orientation = portrait

# 图标和启动图（可选，不设置用默认）
# icon.filename = icon.png
# presplash.filename = splash.png

# Kivy 版本
requirements = python3==3.10.12, kivy==2.3.0

# 日志级别
log_level = 2

# 不包含所有文件
include_patterns =
exclude_patterns = .git, .github, buildozer.spec, *.pyc, __pycache__
