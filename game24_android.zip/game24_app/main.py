"""
24 Point Game - Kivy 安卓版
================================
用 Kivy 做界面，Buildozer 打包成 APK
"""

import random
import itertools
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.graphics import Color, RoundedRectangle

# ── 求解器 ──────────────────────────────────────────────
operators = ['+', '-', '*', '/']

def operate(a, b, op):
    if a is None or b is None:
        return None
    if op == '+': return a + b
    if op == '-': return a - b
    if op == '*': return a * b
    if op == '/':
        if abs(b) < 1e-9:
            return None
        return a / b
    return None

def solve_24(nums):
    solutions = set()
    for perm in set(itertools.permutations(nums)):
        a, b, c, d = perm
        structures = [
            lambda ops: operate(operate(operate(a, b, ops[0]), c, ops[1]), d, ops[2]),
            lambda ops: operate(operate(a, operate(b, c, ops[1]), ops[0]), d, ops[2]),
            lambda ops: operate(operate(a, b, ops[0]), operate(c, d, ops[2]), ops[1]),
            lambda ops: operate(a, operate(operate(b, c, ops[1]), d, ops[2]), ops[0]),
            lambda ops: operate(a, operate(b, operate(c, d, ops[2]), ops[1]), ops[0]),
        ]
        expr_structs = [
            "(({} {} {}) {} {}) {} {}",
            "({} {} ({} {} {})) {} {}",
            "({} {} {}) {} ({} {} {})",
            "{} {} (({} {} {}) {} {})",
            "{} {} ({} {} ({} {} {}))",
        ]
        for ops in itertools.product(operators, repeat=3):
            for idx, struct in enumerate(structures):
                result = struct(ops)
                if result is not None and abs(result - 24) < 1e-6:
                    expr = expr_structs[idx].format(a, ops[0], b, ops[1], c, ops[2], d)
                    solutions.add(expr)
    return sorted(solutions)

def has_solution(nums):
    return len(solve_24(nums)) > 0

def generate_puzzle():
    while True:
        nums = [random.randint(1, 10) for _ in range(4)]
        if has_solution(nums):
            return nums


# ── 卡片控件 ──────────────────────────────────────────────
class CardView(BoxLayout):
    """一张扑克牌样式的卡片"""
    def __init__(self, number, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.size_hint = (None, None)
        self.size = (80, 110)
        self.spacing = 0
        self.padding = [8, 8, 8, 8]

        with self.canvas.before:
            Color(1, 1, 1, 1)
            self.bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[12])

        self.bind(pos=self._update_bg, size=self._update_bg)

        # 上方花色标记（左上）
        top_row = BoxLayout(size_hint=(1, 0.25), orientation='horizontal')
        top_label = Label(
            text='♠', font_size=14, color=(0, 0, 0, 1),
            halign='left', valign='top', size_hint=(1, 1)
        )
        top_row.add_widget(top_label)

        # 中间大数字
        center_label = Label(
            text=str(number), font_size=42, bold=True,
            color=(0, 0, 0, 1), halign='center', valign='middle'
        )

        # 下方花色标记（右下，翻转）
        bottom_row = BoxLayout(size_hint=(1, 0.25), orientation='horizontal')
        bottom_label = Label(
            text='♠', font_size=14, color=(0, 0, 0, 1),
            halign='right', valign='bottom', size_hint=(1, 1)
        )
        bottom_row.add_widget(bottom_label)

        self.add_widget(top_row)
        self.add_widget(center_label)
        self.add_widget(bottom_row)

    def _update_bg(self, *args):
        self.bg.pos = self.pos
        self.bg.size = self.size


# ── 主界面 ──────────────────────────────────────────────
class GameScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.spacing = 15
        self.padding = [20, 30, 20, 30]

        # 状态
        self.cards = []
        self.total = 0
        self.score = 0
        self.solutions = []

        # 背景
        with self.canvas.before:
            Color(0.15, 0.5, 0.2, 1)  # 绿色桌布
            self.bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[0])
        self.bind(pos=self._update_bg, size=self._update_bg)

        # 标题
        title = Label(
            text='🎮 算24点', font_size=36, bold=True,
            color=(1, 1, 1, 1), size_hint=(1, 0.1),
            halign='center', valign='middle'
        )
        self.add_widget(title)

        # 副标题/提示
        self.hint_label = Label(
            text='用 + - × ÷ 和括号，把4张牌算出24',
            font_size=16, color=(1, 1, 0.8, 1), size_hint=(1, 0.06),
            halign='center'
        )
        self.add_widget(self.hint_label)

        # 卡片区域
        self.card_area = BoxLayout(
            orientation='horizontal', size_hint=(1, 0.28),
            spacing=15, padding=[10, 10, 10, 10]
        )
        self.add_widget(self.card_area)

        # 分数显示
        self.score_label = Label(
            text='得分: 0 / 0', font_size=20, bold=True,
            color=(1, 1, 0.9, 1), size_hint=(1, 0.06),
            halign='center'
        )
        self.add_widget(self.score_label)

        # 按钮区域
        btn_layout = GridLayout(
            cols=2, spacing=12, size_hint=(1, 0.12)
        )
        self.btn_show = Button(
            text='👁 看答案', font_size=20, bold=True,
            background_color=(0.2, 0.4, 0.8, 1),
            color=(1, 1, 1, 1)
        )
        self.btn_show.bind(on_press=self.on_show_answer)
        btn_layout.add_widget(self.btn_show)

        self.btn_next = Button(
            text='➡️ 下一题', font_size=20, bold=True,
            background_color=(0.8, 0.4, 0.1, 1),
            color=(1, 1, 1, 1)
        )
        self.btn_next.bind(on_press=self.on_next)
        btn_layout.add_widget(self.btn_next)
        self.add_widget(btn_layout)

        # 反馈区域
        self.feedback_label = Label(
            text='', font_size=18, color=(1, 1, 0.9, 1),
            size_hint=(1, 0.08), halign='center'
        )
        self.add_widget(self.feedback_label)

        # 底部操作按钮
        bottom_layout = BoxLayout(
            orientation='horizontal', size_hint=(1, 0.1), spacing=10
        )
        self.btn_solved = Button(
            text='✅ 我算出来了', font_size=18, bold=True,
            background_color=(0.1, 0.6, 0.2, 1),
            color=(1, 1, 1, 1)
        )
        self.btn_solved.bind(on_press=self.on_solved)
        bottom_layout.add_widget(self.btn_solved)

        self.btn_skip = Button(
            text='⏭ 跳过', font_size=18, bold=True,
            background_color=(0.5, 0.1, 0.1, 1),
            color=(1, 1, 1, 1)
        )
        self.btn_skip.bind(on_press=self.on_skip)
        bottom_layout.add_widget(self.btn_skip)

        self.add_widget(bottom_layout)

        # 启动第一题
        self.new_puzzle()

    def _update_bg(self, *args):
        self.bg.pos = self.pos
        self.bg.size = self.size

    def clear_cards(self):
        self.card_area.clear_widgets()

    def new_puzzle(self):
        """生成新题目"""
        self.cards = generate_puzzle()
        self.solutions = solve_24(self.cards)
        self.clear_cards()
        self.feedback_label.text = ''
        self.hint_label.text = '用 + - × ÷ 和括号，把4张牌算出24'

        # 添加卡片
        for num in self.cards:
            card = CardView(num)
            self.card_area.add_widget(card)
            # 弹性居中
            spacer = BoxLayout(size_hint=(0.5, 1))
            self.card_area.add_widget(spacer)

    def update_score(self):
        self.score_label.text = f'得分: {self.score} / {self.total}'

    def on_solved(self, instance):
        """玩家声明算出来了"""
        self.total += 1
        self.score += 1
        self.update_score()
        self.feedback_label.text = f'🎉 厉害！得分 +1'
        self.show_solutions_popup(auto_close=1.5)

    def on_skip(self, instance):
        """跳过"""
        self.feedback_label.text = '⏭ 已跳过'
        Clock.schedule_once(lambda dt: self.on_next(None), 0.5)

    def on_show_answer(self, instance):
        """显示答案"""
        self.total += 1
        self.update_score()
        self.show_solutions_popup()

    def on_next(self, instance):
        """下一题"""
        self.new_puzzle()

    def show_solutions_popup(self, auto_close=None):
        """弹出答案窗口"""
        content = BoxLayout(orientation='vertical', spacing=10, padding=[15, 15, 15, 15])
        with content.canvas.before:
            Color(0.1, 0.15, 0.2, 0.95)
            bg = RoundedRectangle(pos=content.pos, size=content.size, radius=[15])
            content.bind(pos=lambda *a: setattr(bg, 'pos', content.pos),
                         size=lambda *a: setattr(bg, 'size', content.size))

        title = Label(
            text=f'✅ {len(self.solutions)} 种解法',
            font_size=22, bold=True, color=(1, 1, 0.8, 1),
            size_hint=(1, 0.12)
        )
        content.add_widget(title)

        # 滚动区域放解法列表
        scroll = ScrollView(size_hint=(1, 0.78))
        sol_layout = BoxLayout(
            orientation='vertical', size_hint_y=None, spacing=6
        )
        sol_layout.bind(minimum_height=sol_layout.setter('height'))

        for i, expr in enumerate(self.solutions[:20], 1):
            sol_text = f'  {i}. {expr} = 24'
            lbl = Label(
                text=sol_text, font_size=16, color=(1, 1, 1, 1),
                size_hint_y=None, height=32,
                halign='left', valign='middle'
            )
            lbl.bind(size=lambda s, *a: setattr(s, 'text_size', (s.width, None)))
            sol_layout.add_widget(lbl)

        if len(self.solutions) > 20:
            more = Label(
                text=f'... 还有 {len(self.solutions)-20} 种未显示',
                font_size=14, color=(0.7, 0.7, 0.7, 1),
                size_hint_y=None, height=28
            )
            sol_layout.add_widget(more)

        scroll.add_widget(sol_layout)
        content.add_widget(scroll)

        # 关闭按钮
        close_btn = Button(
            text='关闭', size_hint=(0.5, 0.1),
            pos_hint={'center_x': 0.5},
            background_color=(0.3, 0.5, 0.8, 1),
            color=(1, 1, 1, 1), font_size=18
        )
        content.add_widget(close_btn)

        popup = Popup(
            title='', content=content,
            size_hint=(0.85, 0.7),
            auto_dismiss=True,
            background_color=(0, 0, 0, 0)
        )
        close_btn.bind(on_press=popup.dismiss)

        if auto_close:
            Clock.schedule_once(lambda dt: popup.dismiss(), auto_close)

        popup.open()


# ── App ──────────────────────────────────────────────
class Game24App(App):
    def build(self):
        Window.clearcolor = (0.15, 0.5, 0.2, 1)
        return GameScreen()

    def on_start(self):
        # 防止横屏
        from kivy.utils import platform
        if platform == 'android':
            from android.permissions import request_permissions, Permission
            request_permissions([Permission.INTERNET])

if __name__ == '__main__':
    Game24App().run()
